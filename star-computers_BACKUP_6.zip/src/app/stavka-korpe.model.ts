export interface StavkaKorpe {
  proizvodId: string;
  naziv: string;
  slika: string;
  cena: number;
  kolicina: number;
}
