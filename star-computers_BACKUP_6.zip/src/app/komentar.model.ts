export interface Komentar {
  _id: string;
  autor: string;
  tekst: string;
  odgovor: string;
}
