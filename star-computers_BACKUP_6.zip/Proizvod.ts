export default class Proizvod {
  tip: string;
  naziv: string;
  cena: number;
  slika: string;
  sazetOpis: string;
}
