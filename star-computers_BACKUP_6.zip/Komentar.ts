// export default class Komentar {
//   komentar: string;
//   korisnik: string;
// }ds
