const mongoose = require('mongoose');

const porudzbinaSchema = mongoose.Schema({
  korisnik: { type: mongoose.Schema.Types.ObjectId, ref: "Korisnik", required: true },
  datum: { type: Date, required: true },
  vreme: { type: Date, required: true },
  sadrzaj: [{ proizvodId: String, kolicina: Number }],
  napomena: String
});

module.exports = mongoose.model('Porudzbina', porudzbinaSchema, 'porudzbine');
