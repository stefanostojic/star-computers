const express = require("express");
const multer = require("multer");

const Proizvod = require("../models/proizvod");
const checkIfAdmin = require("../middleware/check-if-admin");

const router = express.Router();

const MIME_TYPE_MAP = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/jpg": "jpg"
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const isValid = MIME_TYPE_MAP[file.mimetype];
    let error = new Error("Invalid mime type");
    if (isValid) {
      error = null;
    }
    cb(error, "backend/images");
  },
  filename: (req, file, cb) => {
    const name = file.originalname
      .toLowerCase()
      .split(" ")
      .join("-");
    const ext = MIME_TYPE_MAP[file.mimetype];
    cb(null, name + "-" + Date.now() + "." + ext);
  }
});

router.post(
  "",
  checkIfAdmin,
  multer({ storage: storage }).single("slika"),
  (req, res, next) => {
    const url = req.protocol + "://" + req.get("host");
    const proizvod = new Proizvod({
      naziv: req.body.naziv,
      sazetOpis: req.body.sazetOpis,
      slika: url + "/images/" + req.file.filename,
      sazetOpis: req.body.sazetOpis,
      detaljanOpis: req.body.detaljanOpis,
      cena: req.body.cena,
      kolicina: req.body.kolicina,
      prodato: req.body.prodato,
      kategorija: req.body.kategorija,
      karakteristike: JSON.parse(req.body.karakteristike),
      komentari: JSON.parse(req.body.komentari)
    });
    proizvod.save().then(sacuvaniProizvod => {
      res.status(201).json({
        proizvod: sacuvaniProizvod
      });
    });
  }
);

router.put("/:id", checkIfAdmin, multer({ storage: storage }).single("slika"), (req, res, next) => {
  console.log('app.js: app.put(): ');
  let slikaPath = req.body.slika;
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    slikaPath = url + "/images/" + req.file.filename
  }
  const proizvod = new Proizvod({
    _id: req.body._id,
    naziv: req.body.naziv,
    slika: slikaPath,
    sazetOpis: req.body.sazetOpis,
    detaljanOpis: req.body.detaljanOpis,
    cena: req.body.cena,
    kolicina: req.body.kolicina,
    prodato: req.body.prodato,
    kategorija: req.body.kategorija,
    karakteristike: req.body.karakteristike,
    komentari: req.body.komentari
  });
  console.log("app.js: Azuriranje proizvoda sa ID: " + req.params.id + " ...");
  Proizvod.updateOne({ _id: req.params.id }, proizvod).then(result => {
    res.status(200).json({ slika: req.body.slika });
    console.log("app.js: Azuriranje proizvoda sa ID: " + req.body._id + " gotovo");
  });
});

router.get("", (req, res, next) => {
  const proizvodiPoStrani = +req.query.proizvodiPoStrani;
  const trenutnaStrana = +req.query.trenutnaStrana;
  const proizvodQuery = Proizvod.find();
  let fetchedProizvodi;
  if (proizvodiPoStrani && trenutnaStrana) {
    proizvodQuery.skip(proizvodiPoStrani * (trenutnaStrana - 1)).limit(proizvodiPoStrani);
  }
  proizvodQuery
    .then(documents => {
      fetchedProizvodi = documents;
      return Proizvod.countDocuments();
    })
    .then(count => {
      // console.log("count: " + count);
      res.status(200).json({
        proizvodi: fetchedProizvodi,
        maxProizvoda: count
      });
    });
});

router.get("/:id", (req, res, next) => {
  Proizvod.findById(req.params.id).then(proizvod => {
    if (proizvod) {
      res.status(200).json(proizvod);
    } else {
      res.status(404).json({ message: "Proizvod not found!" });
    }
  });
});

router.delete("/:id", checkIfAdmin, (req, res, next) => {
  Proizvod.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json({ message: "Proizvod deleted!" });
  });
});

module.exports = router;
