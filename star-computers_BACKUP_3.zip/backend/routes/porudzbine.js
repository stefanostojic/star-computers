const express = require("express");
const Proizvod = require("../models/proizvod");
const Porudzbina = require("../models/porudzbina");
const Obavestenje = require("../models/obavestenje");
const Korisnik = require("../models/korisnik");
const checkIfAdmin = require("../middleware/check-if-admin");
const checkIfKorisnik = require("../middleware/check-if-korisnik");
var mongoose = require('mongoose');
var nodemailer = require('nodemailer');
const checkIfIspravneCene = require("../middleware/check-if-ispravne-cene");

const router = express.Router();

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'mapiranje.la@gmail.com',
    pass: 'lokalni8vodic9'
  }
});

router.post(
  "",
  checkIfKorisnik,
  // checkIfIspravneCene,
  (req, res, next) => {
    console.log("porudzbine.js: io gettovan");
    console.log("porudzbine.js: post: ...");
    const porudzbina = new Porudzbina({
      korisnik: mongoose.Types.ObjectId(req.userData.userId),
      datum: new Date(),
      vreme: new Date(),
      sadrzaj: req.body.stavke,
      napomena: req.body.napomena
    });

    // provera da li su cene okej
    let ukupnaVrednostPorudzbine = 0;
    let ukupanBrojArtikalaPorudzbine = 0;
    let validnostKolicine  = 0;
    let brojac = 0
    for (const stavka of porudzbina.sadrzaj) {
      Proizvod.findById(stavka.proizvodId).then(proizvod => {
        ukupnaVrednostPorudzbine += proizvod.cena * stavka.kolicina;
        ukupanBrojArtikalaPorudzbine += stavka.kolicina;
        if (stavka.kolicina > proizvod.kolicina) {
          validnostKolicine--;
          console.log("NEMA dovoljno na stanju: " + proizvod._id);
        }
        brojac++;
        if (brojac == porudzbina.sadrzaj.length) {
          console.log("ukupnaVrednostPorudzbine na kraju: " + ukupnaVrednostPorudzbine);
          console.log("ukupanBrojArtikalaPorudzbine na kraju: " + ukupanBrojArtikalaPorudzbine);
          porudzbina.save().then(kreiranaPorudzbina => {
            console.log("porudzbine.js: post: porudzbina napravljena");
            Korisnik.findById(req.userData.userId).then(korisnik => {
              const obavestenje = new Obavestenje({
                tip: "porudzbina",
                naziv: korisnik.grad + ", " + korisnik.ulica,
                opis: ukupanBrojArtikalaPorudzbine + " artikal/la ukupne vrednosti: " + ukupnaVrednostPorudzbine + " din",
                datumVreme: kreiranaPorudzbina.datum,
                link: kreiranaPorudzbina._id,
                vidjeno: false
              });
              console.log("obavestenje: " + JSON.stringify(obavestenje));
              obavestenje.save().then(kreiranoObavestenje => {
                console.log("porudzbine.js: post: obavestenje napravljeno");
                console.log("porudzbine.js: io dodatoNovoObavestenje emitovano");
                res.status(201).json({
                  message: "uspeh",
                  obavestenje: kreiranoObavestenje
                });
              });
            });
          });
        }
      });
    }

    // setTimeout(() => {
    //   console.log("ukupnaVrednostPorudzbine na kraju: " + ukupnaVrednostPorudzbine);

    //   porudzbina.save().then(kreiranaPorudzbina => {
    //     console.log("porudzbine.js: post: porudzbina napravljena");

    //     const obavestenje = new Obavestenje({
    //       naziv: "Nova porudzbina za korisnika sa ID-jem: " + req.userData.userId,
    //       opis: "Ukupna vrednost porudzbine: 123",
    //       datumVreme: kreiranaPorudzbina.datum,
    //       link: kreiranaPorudzbina._id,
    //       vidjeno: false
    //     });
    //     obavestenje.save().then(kreiranoObavestenje => {
    //       console.log("porudzbine.js: post: obavestenje napravljeno");
    //       res.status(201).json({
    //         message: "uspeh",
    //         obavestenje: kreiranoObavestenje
    //       });
    //     });
    //   });
    // }, 500);

    // console.log("ukupnaVrednostPorudzbine na kraju: " + ukupnaVrednostPorudzbine);

    // porudzbina.save().then(kreiranaPorudzbina => {
    //   console.log("porudzbine.js: post: porudzbina napravljena");

    //   const obavestenje = new Obavestenje({
    //     naziv: "Nova porudzbina za korisnika sa ID-jem: " + req.userData.userId,
    //     opis: "Ukupna vrednost porudzbine: 123",
    //     datumVreme: kreiranaPorudzbina.datum,
    //     link: kreiranaPorudzbina._id,
    //     vidjeno: false
    //   });
    //   obavestenje.save().then(kreiranoObavestenje => {
    //     console.log("porudzbine.js: post: obavestenje napravljeno");
    //     res.status(201).json({
    //       message: "uspeh",
    //       obavestenje: kreiranoObavestenje
    //     });
    //   });
    // });

  }
);

// router.post(
//   "",
//   checkIfKorisnik,
//   (req, res, next) => {
//     console.log("porudzbine.js: post: ...");
//     const porudzbina = new Porudzbina({
//       korisnik: mongoose.Types.ObjectId(req.userData.userId),
//       datum: new Date(),
//       vreme: new Date(),
//       sadrzaj: req.body.stavke,
//       napomena: req.body.napomena
//     });

//     // provera da li su cene okej
//     let ukupnaVrednostPorudzbine = 0;
//     for (const stavka of porudzbina.sadrzaj) {
//       console.log("prolay");
//       Proizvod.findById(stavka.proizvodId).then(proizvod => {
//         ukupnaVrednostPorudzbine += proizvod.cena;
//       });
//     }

//     setTimeout(() => {
//       console.log("ukupnaVrednostPorudzbine na kraju: " + ukupnaVrednostPorudzbine);
//     }, 5000);
//     // console.log("ukupnaVrednostPorudzbine na kraju: " + ukupnaVrednostPorudzbine);


//     // router.get("/:id", (req, res, next) => {
//     //   Proizvod.findById(req.params.id).then(proizvod => {
//     //     if (proizvod) {
//     //       res.status(200).json(proizvod);
//     //     } else {
//     //       res.status(404).json({ message: "Proizvod not found!" });
//     //     }
//     //   });
//     // });

//     porudzbina.save().then(kreiranaPorudzbina => {
//       console.log("porudzbine.js: post: porudzbina napravljena");

//       const obavestenje = new Obavestenje({
//         naziv: "Nova porudzbina za korisnika sa ID-jem: " + req.userData.userId,
//         opis: "Ukupna vrednost porudzbine: 123",
//         datumVreme: kreiranaPorudzbina.datum,
//         link: kreiranaPorudzbina._id,
//         vidjeno: false
//       });
//       obavestenje.save().then(kreiranoObavestenje => {
//         console.log("porudzbine.js: post: obavestenje napravljeno");
//         res.status(201).json({
//           message: "uspeh",
//           obavestenje: kreiranoObavestenje
//         });
//       });

//       // -polja za novu porudzbinu
//       // -naziv: 'Nova porudzbina na ime: {{korisnik.ime korisnik.prezime}}'
//       // -opis: 'Ukupna vrednost posiljke: {{cena}}'
//       // -datum i vreme: {{new Date()}}
//       // -link: {{porudzbina._id}}

//       // const subjectMejla = "Potvrda porudzbine " + kreiranaPorudzbina._id;
//       // const bodyMejla = `<h1>Star computers</h1><p style="color: red">Postovani, primili smo napomenu: <br>${req.body.napomena}<br>i razmotricemo je</p>`;
//       // var mailOptions = {
//       //   from: 'mapiranje.la@gmail.com',
//       //   to: 'sominiclip@gmail.com',
//       //   subject: subjectMejla,
//       //   text: 'That was easy!',
//       //   html: bodyMejla
//       // };
//       // transporter.sendMail(mailOptions, function(error, info){
//       //   if (error) {
//       //     console.log(error);
//       //   } else {
//       //     console.log('Email sent: ' + info.response);
//       //   }
//       // });
//     });
//   }
// );

module.exports = router;
