export interface Porudzbina {
  _id: string;
  korisnikId: string;
  datum: string;
  vreme: string;
  sadrzaj: { proizvodId: string, kolicina: number }[];
  napomena: string;
}
