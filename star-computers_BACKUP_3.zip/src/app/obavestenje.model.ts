export interface Obavestenje {
  _id: string;
  tip: string;
  naziv: string;
  opis: string;
  datumVreme: string;
  link: string;
  vidjeno: boolean;
}
