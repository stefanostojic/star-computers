import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PocetnaComponent } from './stranica/drugi-red/pocetna/pocetna.component';
import { ProizvodComponent } from './stranica/drugi-red/proizvod/proizvod.component';
import { ProizvodiComponent } from './stranica/drugi-red/administracija/proizvodi/proizvodi.component';
import { PonudaComponent } from './stranica/drugi-red/ponuda/ponuda.component';
import { RegistracijaComponent } from './stranica/drugi-red/registracija/registracija.component';
import { PrijavaComponent } from './stranica/drugi-red/prijava/prijava.component';
import { KorisniciComponent } from './stranica/drugi-red/administracija/korisnici/korisnici.component';
import { PorudzbineComponent } from './stranica/drugi-red/administracija/porudzbine/porudzbine.component';
import { ProfilComponent } from './stranica/drugi-red/profil/profil.component';
import { KorpaComponent } from './stranica/drugi-red/korpa/korpa.component';

const routes: Routes = [
  { path: '', redirectTo: '/pocetna', pathMatch: 'full' },
  { path: 'pocetna', component: PocetnaComponent },
  { path: 'svi-proizvodi', component: PocetnaComponent },
  { path: 'racunari', component: PonudaComponent, pathMatch: 'full' },
  { path: 'racunari/:id', component: ProizvodComponent },
  { path: 'laptopovi/:id', component: ProizvodComponent },
  { path: 'telefoni/:id', component: ProizvodComponent },
  { path: 'proizvod', component: ProizvodComponent },
  { path: 'administracija/proizvodi', component: ProizvodiComponent, pathMatch: 'full'  },
  { path: 'administracija/proizvodi/:id', component: ProizvodiComponent },
  { path: 'administracija/korisnici', component: KorisniciComponent },
  { path: 'administracija/porudzbine', component: PorudzbineComponent },
  { path: 'profil', component: ProfilComponent },
  { path: 'registracija', component: RegistracijaComponent },
  { path: 'prijava', component: PrijavaComponent },
  { path: 'korpa', component: KorpaComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
