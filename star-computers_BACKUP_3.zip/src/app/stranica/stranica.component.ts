import { Component } from '@angular/core';

@Component({
  selector: 'app-stranica',
  templateUrl: './stranica.component.html'
})
export class StranicaComponent {
  title = 'star-computers';
}
