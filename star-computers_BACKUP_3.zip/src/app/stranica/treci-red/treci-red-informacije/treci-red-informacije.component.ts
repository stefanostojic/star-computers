import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treci-red-informacije',
  templateUrl: './treci-red-informacije.component.html'
})
export class TreciRedInformacijeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
