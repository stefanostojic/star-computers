import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProizvodService } from 'src/app/proizvod.service';
import { Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-pretraga',
  templateUrl: './pretraga.component.html',
  styleUrls: ['./pretraga.component.css']
})
export class PretragaComponent implements OnInit, OnDestroy {
  pojamZaPretragu: string;
  cekanjeRezultata: boolean;
  rezultatiSub: Subscription;

  constructor(private proizvodService: ProizvodService) { }

  ngOnInit() {
    this.rezultatiSub = this.proizvodService.getProizvodUpdateListener()
    .subscribe(() => {
      this.cekanjeRezultata = false;
    });
  }

  ngOnDestroy() {
    this.rezultatiSub.unsubscribe();
  }

  pretraga() {
    this.cekanjeRezultata = true;
    this.proizvodService.getProizvodPretraga('Naziv', this.pojamZaPretragu, 20, 1);
  }
}
