import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProizvodService } from 'src/app/proizvod.service';
import { Proizvod } from 'src/app/proizvod.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-ponuda',
  templateUrl: './ponuda.component.html'
})
export class PonudaComponent implements OnInit, OnDestroy {
  proizvodi: Proizvod[] = [];
  private proizvodiSub: Subscription;

  ukupnoProizvoda = 0; // ukupnoProizvoda - totalProducts
  proizvodaPoStrani = 10; // proizvodaPoStrani - productsPerPage
  trenutnaStrana = 1; // trenutnaStrana - currentPage

  constructor(public proizvodService: ProizvodService) { }

  ngOnInit() {
    this.proizvodService.getProizvodi(this.proizvodaPoStrani, this.trenutnaStrana);
    this.proizvodiSub = this.proizvodService
      .getProizvodUpdateListener()
      .subscribe((proizvodiData: { proizvodi: Proizvod[], brojProizvoda: number }) => {
        console.log('Broj proizvoda: ' + proizvodiData.brojProizvoda);
        // window.scrollTo(0, 400);
        const visinaNavigacije = document.getElementById('navigacioniMeni').style.length;
        // alert(visinaNavigacije);
        document.getElementById('sadrzaj').scrollIntoView(true);
        window.scrollBy(0, -visinaNavigacije);
        this.ukupnoProizvoda = proizvodiData.brojProizvoda;
        this.proizvodi = proizvodiData.proizvodi;
      });
  }

  ngOnDestroy() {
    this.proizvodiSub.unsubscribe();
  }

  promenaStrane(param: string) {
    if (param === 'sledeca') {
      if (!(this.trenutnaStrana * this.proizvodaPoStrani < this.ukupnoProizvoda)) {
        return;
      }
      this.trenutnaStrana++;
    } else if (param === 'prethodna') {
      if (this.trenutnaStrana === 1) {
        return;
      }
      this.trenutnaStrana--;
    }
    this.proizvodService.getProizvodi(this.proizvodaPoStrani, this.trenutnaStrana);
  }

  // onChangedPage(pageData: PageEvent) {
  //   this.isLoading = true;
  //   this.currentPage = pageData.pageIndex + 1;
  //   this.postsPerPage = pageData.pageSize;
  //   this.postsService.getPosts(this.postsPerPage, this.currentPage);
  // }
}
