import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-numeracija',
  templateUrl: './numeracija.component.html'
})
export class NumeracijaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
