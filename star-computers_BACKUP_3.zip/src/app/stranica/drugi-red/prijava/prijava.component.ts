import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../../../auth.service';

@Component({
  selector: 'app-prijava',
  templateUrl: './prijava.component.html'
})
export class PrijavaComponent implements OnInit {
  constructor(private authService: AuthService) { }

  prijavaForm: FormGroup;

  ngOnInit() {
    this.prijavaForm = new FormGroup({
      email: new FormControl(null, { validators: [Validators.required, Validators.email] }),
      lozinka: new FormControl(null, { validators: [Validators.required, Validators.minLength(8)] }),
    });
    this.prijavaForm.reset();
  }

  prijava() {
    if (this.prijavaForm.invalid) {
      console.log('invalid form shit');
      console.log('this.prijavaForm.get(email).invalid: ' + this.prijavaForm.get('email').invalid);
      console.log('this.prijavaForm.get(lozinka).invalid: ' + this.prijavaForm.get('lozinka').invalid);
      return;
    }
    console.log('nastavak prijave...');
    this.authService.prijava(this.prijavaForm.get('email').value, this.prijavaForm.get('lozinka').value);
  }
}
