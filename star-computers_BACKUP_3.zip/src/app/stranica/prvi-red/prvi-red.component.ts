import { Component } from '@angular/core';

@Component({
  selector: 'app-prvi-red',
  templateUrl: './prvi-red.component.html'
})
export class PrviRedComponent {
  title = 'star-computers';
}
