import { Injectable, OnInit, OnDestroy } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Subject } from 'rxjs';

import { Korisnik } from './korisnik.model';
import { Porudzbina } from './porudzbina.model';
import { StavkaKorpe } from './stavka-korpe.model';
import { ObavestenjeService } from './obavestenje.service';
import { Obavestenje } from './obavestenje.model';

@Injectable({ providedIn: 'root' })
export class PorudzbinaService {
  private porudzbine: Porudzbina[] = [];
  private porudzbineUpdated = new Subject<Porudzbina[]>();
  private stanjePorudzbine = new Subject<{ stanje: string, poruka: string}>();


  constructor(private http: HttpClient, private obavestenjeService: ObavestenjeService) {}

  getPorudzbineUpdateListener() {
    return this.porudzbineUpdated.asObservable();
  }

  getPotvrdaPorudzbineUpdateListener() {
    return this.stanjePorudzbine.asObservable();
  }

  // get porudzbine koje nisu obradjena ili jesu
  getPorudzbine() {
    console.log('porudzbine.service: getPorudzbine(): ...');
    this.http.get<{ porudzbine: any }>('http://localhost:3000/api/porudzbine/')
    .subscribe(data => {
      this.porudzbine = data.porudzbine;
      this.porudzbineUpdated.next([...this.porudzbine]);
      console.log('porudzbine.service: getPorudzbine(): gotovo');
    });
  }

  // getKorisnici() {
  //   console.log('korisnici.service: getKorisnici(): ...');
  //   this.http.get<{ korisnici: any }>('http://localhost:3000/api/korisnici/')
  //   .subscribe(data => {
  //     this.korisnici = data.korisnici;
  //     this.korisniciUpdated.next([...this.korisnici]);
  //     console.log('korisnici.service: getKorisnici(): gotovo');
  //   });
  // }

  getPorudzbina(id: string) {
    return this.http.get<{
      _id: string,
      korisnikId: string,
      datum: string,
      vreme: string,
      sadrzaj: { proizvodId: string, kolicina: number }[],
      napomena: string,
    }>('http://localhost:3000/api/porudzbine' + id);
  }

  // getKorisnik(id: string) {
  //   return this.http.get<{
  //     _id: string,
  //     email: string,
  //     ime: string,
  //     prezime: string,
  //     telefon: string,
  //     grad: string,
  //     ulica: string,
  //     postanskiBroj: number
  //   }>('http://localhost:3000/api/korisnici' + id);
  // }

  addPorudzbina(korpa: StavkaKorpe[]) {
    console.log('porudzbina.service: addPorudzbina(): korpa: ' + JSON.stringify(korpa));
    const data = [] as { proizvodId: string, kolicina: number }[];
    for (const stavka of korpa) {
      data.push({proizvodId: stavka.proizvodId, kolicina: stavka.kolicina});
    }
    const paket = { stavke: data };
    console.log('porudzbina.service: addPorudzbina(): data: ' + JSON.stringify(data));
    this.http.post<{message: string, obavestenje: Obavestenje }>('http://localhost:3000/api/porudzbine', paket)
    .subscribe(response => {
      console.log('porudzbina.service: addPorudzbina(): cuvanje porudzbine gotovo');
      console.log('porudzbina.service: addPorudzbina(): kreirano obavestenje: ' + JSON.stringify(response.obavestenje));
      if (response.message === 'uspeh') {
        this.stanjePorudzbine.next({
          stanje: 'Uspešno ste napravili porudžbinu!',
          poruka: ''
        });
      } else {
        this.stanjePorudzbine.next({
          stanje: 'Došlo je do greške prilikom potvrđivanja Vaše porudžbine. Molimo Vas da nam se obratite putem kontakt centra.',
          poruka: ''
        });
        console.log('response.message: ' + response.message);
      }
    },
    error => {
      console.log('oops', error);
      this.stanjePorudzbine.next({
        stanje: 'Došlo je do greške prilikom potvrđivanja Vaše porudžbine. Molimo Vas da nam se obratite putem kontakt centra.',
        poruka: ''
      });
    });
  }

  // postavlja porudzbina.obradjena na true
  obradaPorudzbine(porudzbinaId: Porudzbina) {
    console.log('porudzbina.service: obradaPorudzbine(): ' + porudzbinaId);
    this.http.put('http://localhost:3000/api/porudzbine/' + porudzbinaId, null)
    .subscribe(response => {
      console.log('porudzbina.service: obradaPorudzbine(): successful');
      // const updatedKorisnici = [...this.korisnici];
      // const oldKorisnikIndex = updatedKorisnici.findIndex(p => p._id === idParam);
      // updatedKorisnici[oldKorisnikIndex] = korisnik;
      // this.korisnici = updatedKorisnici;
      // this.korisniciUpdated.next([...this.korisnici]);
    });
  }

  // updateKorisnik(
  //   idParam: string,
  //   emailParam: string,
  //   imeParam: string,
  //   prezimeParam: string,
  //   telefonParam: string,
  //   gradParam: string,
  //   ulicaParam: string,
  //   postanskiBrojParam: number
  // ) {
  //   const korisnik: Korisnik = {
  //     _id: idParam,
  //     email: emailParam,
  //     ime: imeParam,
  //     prezime: prezimeParam,
  //     telefon: telefonParam,
  //     grad: gradParam,
  //     ulica: ulicaParam,
  //     postanskiBroj: postanskiBrojParam
  //   };
  //   console.log('korisnici.service: updateKorisnik(): ' + korisnik);
  //   this.http.put('http://localhost:3000/api/korisnici/' + idParam, korisnik)
  //   .subscribe(response => {
  //     console.log('korisnici.service: updateKorisnik() successful');
  //     const updatedKorisnici = [...this.korisnici];
  //     const oldKorisnikIndex = updatedKorisnici.findIndex(p => p._id === idParam);
  //     updatedKorisnici[oldKorisnikIndex] = korisnik;
  //     this.korisnici = updatedKorisnici;
  //     this.korisniciUpdated.next([...this.korisnici]);
  //   });
  // }

  dodajUKorpu(stavka: StavkaKorpe) {
    console.log('porudzbina.service: dodajUKorpu(): ...');

    const korpa = localStorage.getItem('korpa');
    if (korpa) {
      console.log('localStorage.getItem(korpa): ' + korpa);
      const korpaObj: StavkaKorpe[] = JSON.parse(korpa);
      const indexStarogZapisa = korpaObj.findIndex(z => z.proizvodId === stavka.proizvodId);
      console.log('indexStarogZapisa: ' + indexStarogZapisa);
      if (indexStarogZapisa > -1) {
        const stavkaKorpe = korpaObj[indexStarogZapisa];
        stavkaKorpe.kolicina += stavka.kolicina;
        korpaObj[indexStarogZapisa] = stavkaKorpe;
        localStorage.setItem('korpa', JSON.stringify(korpaObj));
      } else {
        korpaObj.push(stavka);
        localStorage.setItem('korpa', JSON.stringify(korpaObj));
      }
    } else {
      console.log('localStorage.getItem(korpa): ' + korpa);
      const korpaObj: { proizvodId: string, kolicina: number }[] = [];
      korpaObj.push(stavka);
      localStorage.setItem('korpa', JSON.stringify(korpaObj));
    }

    console.log('porudzbina.service: dodajUKorpu(): gotovo');
  }

  azurirajKorpu(proizvodId: string, kolicina: number) {
    console.log('porudzbina.service: azurirajKorpu(): ...');

    const korpa = localStorage.getItem('korpa');
    const korpaObj: { proizvodId: string, kolicina: number }[] = JSON.parse(korpa);
    const indexStarogZapisa = korpaObj.findIndex(z => z.proizvodId === proizvodId);
    korpaObj[indexStarogZapisa].kolicina = kolicina;
    localStorage.setItem('korpa', JSON.stringify(korpaObj));

    console.log('porudzbina.service: azurirajKorpu(): gotovo');
  }

  obrisiIzKorpe(proizvodId: string) {
    const korpa = localStorage.getItem('korpa');
    const korpaObj: StavkaKorpe[] = JSON.parse(korpa);
    const novaKorpa = korpaObj.filter(z => z.proizvodId !== proizvodId);
    localStorage.setItem('korpa', JSON.stringify(novaKorpa));
  }
}
