import { Component, OnInit, OnDestroy  } from '@angular/core';
import { Subscription } from 'rxjs';

import { Proizvod } from '../../../../proizvod.model';
import { Karakteristika } from '../../../../karakteristika.model';
import { Komentar } from '../../../../komentar.model';
import { ProizvodService } from '../../../../proizvod.service';
import { FormGroup, FormControl, Validators, FormGroupDirective } from '@angular/forms';
import { mimeType } from '../mime-type.validator';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-proizvodi',
  templateUrl: './proizvodi.component.html',
  styleUrls: ['./proizvodi.component.css']
})

export class ProizvodiComponent implements OnInit, OnDestroy {
  proizvodi: Proizvod[] = [];
  private proizvodiSub: Subscription;

  odabraniKriterijumPretrage = 'ID'; // ili 'Naziv' ili 'Sazet opis'
  pojamZaPretragu = '';

  rezim = 'dodavanje'; // ili 'izmena'

  tempKarakteristika: Karakteristika = {
    naziv: '',
    vrednost: ''
  };
  rezimKarakateristike = 'dodavanje'; // ili 'izmena'

  tempKomentar: Komentar = {
    _id: '',
    autor: '',
    tekst: '',
    odgovor: ''
  };

  vidljivostFormeZaOdgovaranje = false;
  formaZaOdgovoranjeId = '';
  pretragaUToku = true;
  cuvanjeUToku = false;
  prikazUspesnogCuvanja = false;

  proizvodForm: FormGroup;
  karakteristikaForm: FormGroup;
  slikaPreview: string;
  listaKarakteristika = [] as Karakteristika[];
  listaKomentara = [] as Komentar[];

  trebaObraditiIdParam = true;

  ukupnoProizvoda = 0; // ukupnoProizvoda - totalProducts
  proizvodaPoStrani = 10; // proizvodaPoStrani - productsPerPage
  trenutnaStrana = 1; // trenutnaStrana - currentPage

  constructor(public proizvodService: ProizvodService, private route: ActivatedRoute) {}

  ngOnInit() {
    this.proizvodForm = new FormGroup({
      id: new FormControl(null),
      naziv: new FormControl(null, { validators: [Validators.required] }),
      kategorija: new FormControl('Računar', { validators: [Validators.required] }),
      cena: new FormControl(null, { validators: [Validators.required] }),
      kolicina: new FormControl(null, { validators: [Validators.required] }),
      prodato: new FormControl(0, { validators: [Validators.required] }),
      sazetOpis: new FormControl(null, { validators: [Validators.required] }),
      detaljanOpis: new FormControl(null, { validators: [Validators.required] }),
      slika: new FormControl(null, {
        validators: [Validators.required],
        asyncValidators: [mimeType]
      })
    });
    this.proizvodForm.reset();
    this.proizvodService.getProizvodi(
      this.odabraniKriterijumPretrage,
      this.pojamZaPretragu,
      this.proizvodaPoStrani,
      this.trenutnaStrana
    );
    this.proizvodiSub = this.proizvodService.getProizvodUpdateListener()
    .subscribe(data => {
      this.pretragaUToku = false;
      if (this.cuvanjeUToku) {
        this.prikazUspesnogCuvanja = true;
      }
      this.cuvanjeUToku = false;

      this.proizvodi = data.proizvodi;
      this.ukupnoProizvoda = data.brojProizvoda;
      const id = this.route.snapshot.paramMap.get('id');
      if (this.trebaObraditiIdParam && id) {
        this.trebaObraditiIdParam = false;
        const proizvodTemp = this.proizvodi.find(proizvod => proizvod._id === id);
        console.log('iz URL-a pronadjen proizvod');
        this.odabirProizvoda(proizvodTemp);
      }
    });
  }

  proveriIspravnostSlike() {
    console.log('this.proizvodForm.get(slika).invalid: ' + this.proizvodForm.get('slika').invalid);
    console.log('this.slikaPreview: ' + this.slikaPreview);
  }

  ngOnDestroy() {
    this.proizvodiSub.unsubscribe();
  }

  onSubmit(formDirective: FormGroupDirective) {
    console.log('Angular: onSubmin()');
    if (this.proizvodForm.invalid) {
      console.log('Neka polja nisu ispravno popunjana.');
      this.proizvodForm.markAllAsTouched();
      return;
    }
    this.cuvanjeUToku = true;
    if (this.rezim === 'dodavanje') {
      console.log('Angular: Obavlja se dodavanje: ');
      this.proizvodService.addProizvod(
        this.proizvodForm.value.naziv,
        this.proizvodForm.value.slika,
        this.proizvodForm.value.sazetOpis,
        this.proizvodForm.value.detaljanOpis,
        this.proizvodForm.value.cena,
        this.proizvodForm.value.kolicina,
        this.proizvodForm.value.prodato,
        this.proizvodForm.value.kategorija,
        this.listaKarakteristika,
        this.listaKomentara
      );
    } else {
      console.log('Angular: Obavlja se azuriranje: ');
      this.proizvodService.updateProizvod(
        this.proizvodForm.value.id,
        this.proizvodForm.value.naziv,
        this.proizvodForm.value.slika,
        this.proizvodForm.value.sazetOpis,
        this.proizvodForm.value.detaljanOpis,
        this.proizvodForm.value.cena,
        this.proizvodForm.value.kolicina,
        this.proizvodForm.value.prodato,
        this.proizvodForm.value.kategorija,
        this.listaKarakteristika,
        this.listaKomentara
      );
    }
    this.proizvodForm.reset();
    formDirective.resetForm();
    this.proizvodForm.updateValueAndValidity();
    this.listaKarakteristika = [] as Karakteristika[];
    this.listaKomentara = [] as Komentar[];
    this.slikaPreview = '';
  }

  pretragaProizvoda() {
    console.log('Pretraga zapoceta');
    this.pretragaUToku = true;
    this.proizvodService.getProizvodi(
      this.odabraniKriterijumPretrage,
      this.pojamZaPretragu,
      this.proizvodaPoStrani,
      this.trenutnaStrana
    );
  }

  odabirKriterijumaID() {
    this.odabraniKriterijumPretrage = 'ID';
  }

  odabirKriterijumaNaziv() {
    this.odabraniKriterijumPretrage = 'Naziv';
  }

  odabirKriterijumaSazetOpis() {
    this.odabraniKriterijumPretrage = 'Sazet opis';
  }

  odabirProizvoda(proizvod: Proizvod) {
    // if (this.odabraniproizvod._id === '' || this.odabraniProizvod !== proizvod) {
    if (this.proizvodForm.get('id').value === null || this.proizvodForm.get('id').value !== proizvod._id) {
      console.log('Odabir proizvoda: ' + proizvod._id);
      this.proizvodForm.setValue({
        id: proizvod._id,
        naziv: proizvod.naziv,
        slika: proizvod.slika,
        sazetOpis: proizvod.sazetOpis,
        detaljanOpis: proizvod.detaljanOpis,
        cena: proizvod.cena,
        kolicina: proizvod.kolicina,
        prodato: proizvod.prodato,
        kategorija: proizvod.kategorija
      });
      this.listaKarakteristika = proizvod.karakteristike;
      this.listaKomentara = proizvod.komentari;
      this.slikaPreview = proizvod.slika;
      this.rezim = 'izmena';
    } else {
      console.log('Odabir proizvoda: ' + null);
      this.proizvodForm.reset();
      this.listaKarakteristika = null;
      this.listaKomentara = null;
      this.rezim = 'dodavanje';
    }
    // this.tempProizvod = this.odabraniProizvod;
  }

  // kloniranjeProizvoda(zaKloniranje: Proizvod): Proizvod {
  //   console.log('Angular: kloniranjeProizvoda(): ' + JSON.stringify(zaKloniranje));
  //   const tempKarakteristike: Karakteristika[] = [];
  //   const proizvod: Proizvod = {
  //     _id: zaKloniranje._id,
  //     naziv: zaKloniranje.naziv,
  //     slika: zaKloniranje.slika,
  //     sazetOpis: zaKloniranje.sazetOpis,
  //     detaljanOpis: zaKloniranje.detaljanOpis,
  //     cena: zaKloniranje.cena,
  //     kolicina: zaKloniranje.kolicina,
  //     prodato: zaKloniranje.prodato,
  //     kategorija: zaKloniranje.kategorija,
  //     karakteristike: zaKloniranje.karakteristike, // [...zaKloniranje.karakteristike],
  //     komentari: zaKloniranje.komentari // [...zaKloniranje.komentari]
  //   };
  //   return proizvod;
  // }

  delete() {
    this.proizvodService.deleteProizvod(this.proizvodForm.get('id').value);
  }

  prikazDugmetaOdustani(): boolean {
    let odluka = false;
    // if (
    //   this.rezim === 'dodavanje' &&
    //   this.tempProizvod._id === '' && (
    //   this.tempProizvod.naziv !== '' ||
    //   this.tempProizvod.slika !== '' ||
    //   this.tempProizvod.sazetOpis !== '' ||
    //   this.tempProizvod.detaljanOpis !== '' ||
    //   this.tempProizvod.cena !== 0 ||
    //   this.tempProizvod.kolicina !== 0 ||
    //   this.tempProizvod.kategorija !== '' ||
    //   // this.tempProizvod.karakteristike !== [] || // null
    //   // this.tempProizvod.komentari !== [] // null
    //   this.tempProizvod.karakteristike.length !== 0 || // null
    //   this.tempProizvod.komentari.length !== 0 // null
    //   )) {
    //   odluka = true;
    // }
    return odluka;
  }

  odabirKarakteristike(karakteristika: { id: string, naziv: string, vrednost: string }) {
    if (this.tempKarakteristika.naziv !== karakteristika.naziv) {
      this.tempKarakteristika.naziv = karakteristika.naziv;
      this.tempKarakteristika.vrednost = karakteristika.vrednost;
      this.rezimKarakateristike = 'izmena';
      console.log('Selekcija karakteristike: ' + JSON.stringify(karakteristika));
    } else {
      this.tempKarakteristika.naziv = '';
      this.tempKarakteristika.vrednost = '';
      this.rezimKarakateristike = 'dodavanje';
      console.log('Deselekcija karakteristike: ' + JSON.stringify(karakteristika));
    }
  }

  saveKarakteristika() {
    console.log('Angular: saveKarakteristika(): ' + this.rezimKarakateristike + ': ' + JSON.stringify(this.tempKarakteristika));
    if (this.rezimKarakateristike === 'dodavanje') {
      this.listaKarakteristika.push(this.tempKarakteristika);
    } else {
      let index = -1;
      let i = 0;

      for (const karakteristika of this.listaKarakteristika) {
        if (karakteristika.naziv === this.tempKarakteristika.naziv) {
          console.log('Angular: saveKarakteristika(): index: ' + i);
          index = i;
          break;
        }
        i++;
      }
      if (index !== -1 ) {
        this.listaKarakteristika[index] = {
          naziv: this.tempKarakteristika.naziv,
          vrednost: this.tempKarakteristika.vrednost
        };
        console.log('Angular: saveKarakteristika(): izmena sacuvana');
      }
    }
    this.rezimKarakateristike = 'dodavanje';

    // this.tempProizvod.karakteristike.push({
    //   id: this.tempKarakteristika.
    // });
  }

  deleteKarakteristika() {
    console.log('Angular: deleteKarakteristika(): ' + JSON.stringify(this.tempKarakteristika));
    this.listaKarakteristika = this.listaKarakteristika.filter(
      karakteristika => karakteristika.naziv !== this.tempKarakteristika.naziv
    );
    this.tempKarakteristika.naziv = '';
    this.tempKarakteristika.vrednost = '';
    this.rezimKarakateristike = 'dodavanje';
  }

  odabirKomentara(komentar: Komentar) {
    if (this.tempKomentar._id !== komentar._id) {
      this.tempKomentar._id = komentar._id;
      this.tempKomentar.autor = komentar.autor;
      this.tempKomentar.tekst = komentar.tekst;
      this.tempKomentar.odgovor = komentar.odgovor;
      console.log('Selekcija komentara: ' + JSON.stringify(this.tempKomentar));
    } else {
      this.tempKomentar._id = '';
      this.tempKomentar.autor = '';
      this.tempKomentar.tekst = '';
      this.tempKomentar.odgovor = '';
      this.vidljivostFormeZaOdgovaranje = false;
      console.log('Deselekcija komentara: ' + JSON.stringify(this.tempKomentar));
    }
  }

  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.proizvodForm.patchValue({ slika: file });
    this.proizvodForm.get('slika').updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      this.slikaPreview = reader.result as string;
    };
    reader.readAsDataURL(file);
  }

  promenaStrane(param: string) {
    if (param === 'sledeca') {
      if (!(this.trenutnaStrana * this.proizvodaPoStrani < this.ukupnoProizvoda)) {
        alert('nema dalje');
        return;
      }
      this.trenutnaStrana++;
    } else if (param === 'prethodna') {
      if (this.trenutnaStrana === 1) {
        alert('ne moze nazad');
        return;
      }
      this.trenutnaStrana--;
    }
    this.proizvodService.getProizvodi(
      this.odabraniKriterijumPretrage,
      this.pojamZaPretragu,
      this.proizvodaPoStrani,
      this.trenutnaStrana
    );
  }
}
