import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { ProizvodService } from '../../../proizvod.service';
import { Proizvod } from 'src/app/proizvod.model';
import { Komentar } from 'src/app/komentar.model';
import { PorudzbinaService } from 'src/app/porudzbina.service';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-proizvod',
  templateUrl: './proizvod.component.html',
  styleUrls: [ './proizvod.component.css' ]
})


export class ProizvodComponent implements OnInit {

  noviKomentar: Komentar = {
    _id: '',
    autor: '',
    tekst: '',
    odgovor: ''
  };
  linkKaKategoriji = 'kategorija proizvoda';
  proizvod: Proizvod = {
    _id: '',
    naziv: '',
    slika: '',
    sazetOpis: '',
    detaljanOpis: '',
    cena: 0,
    kolicina: 0,
    prodato: 0,
    kategorija: '',
    karakteristike: [],
    komentari: []
  };
  kolicina = 1;
  ulogovanost = false;
  prikazUpozorenja = false;

  constructor(
    private proizvodService: ProizvodService,
    private porudzbinaService: PorudzbinaService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private location: Location
    ) {}

  ngOnInit() {
    this.getProizvod();
    this.ulogovanost = this.authService.getIsAuth();
    console.log('DA LI JE KORISNIK PRIJAVLJEN: ' + this.ulogovanost);
  }

  getProizvod() {
    console.log('Angular: getProizvod(): id: ' + this.route.snapshot.paramMap.get('id'));
    const id = this.route.snapshot.paramMap.get('id');

    this.proizvodService.getProizvod(id.toString())
      .subscribe(proizvod => {
        this.proizvod = proizvod;
        console.log('Angular: getProizvod(): ' + JSON.stringify(proizvod));
        switch (proizvod.kategorija) {
          case 'Računar':
            this.linkKaKategoriji = 'racunari';
            break;
          case 'Laptop':
            this.linkKaKategoriji = 'laptopovi';
            break;
          case 'Telefon':
            this.linkKaKategoriji = 'telefoni';
            break;
          default:
            this.linkKaKategoriji = 'svi-proizvodi';
            break;
        }
      });
  }

  addKomentar() {
    console.log('Angular: addKomentar(): ' + this.proizvod._id + ', ' + this.noviKomentar.autor + ', ' + this.noviKomentar.tekst);
    this.proizvodService.addKomentar(this.proizvod._id, this.noviKomentar);
  }

  dodajUKorpu() {
    if (!this.ulogovanost) {
      console.log('this.authService.getIsAuth: ' + this.authService.getIsAuth);
      this.prikazUpozorenja = true;
    } else {
      console.log('Angular: dodajUKorpu(): ...');
      this.porudzbinaService.dodajUKorpu({
        proizvodId: this.proizvod._id,
        naziv: this.proizvod.naziv,
        slika: this.proizvod.slika,
        cena: this.proizvod.cena,
        kolicina: this.kolicina});
      this.router.navigate(['/korpa']);
    }
  }
}
