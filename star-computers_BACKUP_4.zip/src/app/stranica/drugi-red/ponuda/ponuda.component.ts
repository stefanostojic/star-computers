import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProizvodService } from 'src/app/proizvod.service';
import { Proizvod } from 'src/app/proizvod.model';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ponuda',
  templateUrl: './ponuda.component.html'
})
export class PonudaComponent implements OnInit, OnDestroy {
  proizvodi: Proizvod[] = [];
  private proizvodiSub: Subscription;
  ucitavanje = false;

  ukupnoProizvoda = 0; // ukupnoProizvoda - totalProducts
  proizvodaPoStrani = 10; // proizvodaPoStrani - productsPerPage
  trenutnaStrana = 1; // trenutnaStrana - currentPage

  querySub: Subscription;
  odabraniPojam: string;
  odabraniKriterijum: string;

  constructor(public proizvodService: ProizvodService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.ucitavanje = true;
    this.proizvodiSub = this.proizvodService
      .getProizvodUpdateListener()
      .subscribe((proizvodiData: { proizvodi: Proizvod[], brojProizvoda: number }) => {
        console.log('ponudaComponent: ukupan broj proizvoda: ' + proizvodiData.brojProizvoda);
        this.ukupnoProizvoda = proizvodiData.brojProizvoda;
        this.proizvodi = proizvodiData.proizvodi;
        this.ucitavanje = false;
      });
    this.querySub = this.activatedRoute.queryParams.subscribe(params => {
      this.odabraniKriterijum = params['kriterijum'.toString()];
      this.odabraniPojam = params['pojam'.toString()];
      console.log('ponudaComponent: ngOnInit(): odabraniKriterijum: ', this.odabraniKriterijum);
      console.log('ponudaComponent: ngOnInit(): odabraniPojam: ', this.odabraniPojam);
      if (this.odabraniKriterijum === 'Kategorija') {
        this.proizvodService.getProizvodi('Kategorija', this.odabraniPojam, this.proizvodaPoStrani, this.trenutnaStrana);
      } else if (this.odabraniKriterijum === 'Naziv') {
        this.proizvodService.getProizvodi('Naziv', this.odabraniPojam, this.proizvodaPoStrani, this.trenutnaStrana);
      } else if (this.odabraniKriterijum === 'NazivIliSazetOpis') {
        this.proizvodService.getProizvodi('NazivIliSazetOpis', this.odabraniPojam, this.proizvodaPoStrani, this.trenutnaStrana);
      } else {
        this.proizvodService.getProizvodi(
          '',
          '',
          this.proizvodaPoStrani,
          this.trenutnaStrana
        );
      }
    });
  }

  ngOnDestroy() {
    this.proizvodiSub.unsubscribe();
    this.querySub.unsubscribe();
  }

  promenaStrane(param: string) {
    if (param === 'sledeca') {
      if (!(this.trenutnaStrana * this.proizvodaPoStrani < this.ukupnoProizvoda)) {
        return;
      }
      this.trenutnaStrana++;
    } else if (param === 'prethodna') {
      if (this.trenutnaStrana === 1) {
        return;
      }
      this.trenutnaStrana--;
    }
    this.ucitavanje = true;
    if (this.odabraniKriterijum === 'Kategorija') {
      this.proizvodService.getProizvodi('Kategorija', this.odabraniPojam, this.proizvodaPoStrani, this.trenutnaStrana);
    } else if (this.odabraniKriterijum === 'Naziv') {
      this.proizvodService.getProizvodi('Naziv', this.odabraniPojam, this.proizvodaPoStrani, this.trenutnaStrana);
    } else {
      this.proizvodService.getProizvodi(
        '',
        '',
        this.proizvodaPoStrani,
        this.trenutnaStrana
      );
    }
  }

  // onChangedPage(pageData: PageEvent) {
  //   this.isLoading = true;
  //   this.currentPage = pageData.pageIndex + 1;
  //   this.postsPerPage = pageData.pageSize;
  //   this.postsService.getPosts(this.postsPerPage, this.currentPage);
  // }
}
