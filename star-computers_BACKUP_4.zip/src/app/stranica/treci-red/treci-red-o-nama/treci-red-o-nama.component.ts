import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treci-red-o-nama',
  templateUrl: './treci-red-o-nama.component.html'
})
export class TreciRedONamaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
