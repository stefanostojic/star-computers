export interface Karakteristika {
  naziv: string;
  vrednost: string;
}
