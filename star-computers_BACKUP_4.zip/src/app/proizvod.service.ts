import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Proizvod, ProizvodMin } from './proizvod.model';
import { Karakteristika } from './karakteristika.model';
import { Komentar } from './komentar.model';
import { Subject } from 'rxjs';
import { UpperCasePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ProizvodService {
  private proizvodi: Proizvod[] = [];
  private proizvodiUpdated = new Subject<{ proizvodi: Proizvod[], brojProizvoda: number }>();
  private proizvodiUpdatedZaSveProizvode = new Subject<Proizvod[]>();

  constructor(private http: HttpClient) {}

  addProizvod(
    nazivParam: string, slikaParam: File, sazetOpisParam: string, detaljanOpisParam: string, cenaParam: number,
    kolicinaParam: number, prodato: number, kategorijaParam: string, karakteristikeParam: Karakteristika[], komentariParam: Komentar[]) {
    const proizvodData = new FormData();
    proizvodData.append('naziv', nazivParam);
    proizvodData.append('sazetOpis', sazetOpisParam);
    proizvodData.append('detaljanOpis', detaljanOpisParam);
    proizvodData.append('cena', cenaParam.toString());
    proizvodData.append('kolicina', kolicinaParam.toString());
    proizvodData.append('prodato', prodato.toString());
    proizvodData.append('kategorija', kategorijaParam);
    proizvodData.append('slika', slikaParam, nazivParam);
    proizvodData.append('karakteristike', JSON.stringify(karakteristikeParam));
    proizvodData.append('komentari', JSON.stringify(komentariParam));
    console.log('proizvod.service: addProizvod(): Slanje proizvoda na server...');
    this.http
      .post<{ proizvod: Proizvod }>(
        'http://localhost:3000/api/proizvodi',
        proizvodData
      )
      .subscribe(responseData => {
        const proizvod: Proizvod = {
          _id: responseData.proizvod._id,
          naziv: nazivParam,
          sazetOpis: sazetOpisParam,
          detaljanOpis: detaljanOpisParam,
          cena: cenaParam,
          kolicina: kolicinaParam,
          prodato,
          kategorija: kategorijaParam,
          slika: responseData.proizvod.slika,
          karakteristike: karakteristikeParam,
          komentari: komentariParam
        };
        this.proizvodi.push(proizvod);
        this.proizvodiUpdatedZaSveProizvode.next([...this.proizvodi]);
        // // this.router.navigate(['/']);
        console.log('proizvod.service: Proizvod uspesno poslat na server');
      });
  }

  // getProizvodi(proizvodiPoStrani: number, trenutnaStrana: number) {
  //   console.log('proizvod.service: getProizvodi()...');
  //   const queryParams = `?proizvodiPoStrani=${proizvodiPoStrani}&trenutnaStrana=${trenutnaStrana}`;
  //   this.http
  //     .get<{ message: string; proizvodi: any, maxProizvoda: number }>(
  //       'http://localhost:3000/api/proizvodi' + queryParams
  //     )
  //     .subscribe(data => {
  //       this.proizvodi = data.proizvodi;
  //       this.proizvodiUpdated.next({
  //         proizvodi: [...this.proizvodi],
  //         brojProizvoda: data.maxProizvoda
  //       });
  //       console.log('proizvod.service: getProizvodi() gotovo');
  //     });
  // }

  getProizvodi(
    naziv: string,
    cenaMin: number,
    cenaMax: number,
    prodatoMin: number,
    prodatoMax: number,
    kolicinaMin: number,
    kolicinaMax: number,
    sortiranje: string,
    proizvodiPoStrani: number,
    trenutnaStrana: number
    ) {

    let queryParams = `?`;
    queryParams += `naziv=${naziv}`;
    queryParams += `&cenaMin=${cenaMin}`;
    queryParams += `&cenaMax=${cenaMax}`;
    queryParams += `&prodatoMin=${prodatoMin}`;
    queryParams += `&prodatoMax=${prodatoMax}`;
    queryParams += `&kolicinaMin=${kolicinaMin}`;
    queryParams += `&kolicinaMax=${kolicinaMax}`;
    queryParams += `&sortiranje=${sortiranje}`;
    queryParams += `&proizvodiPoStrani=${proizvodiPoStrani}`;
    queryParams += `&trenutnaStrana=${trenutnaStrana}`;

    console.log('proizvod.service: getProizvodi(): queryParams: ', queryParams);

    this.http.get<{ proizvodi: Proizvod[], ukupnoProizvoda: number }>(
      'http://localhost:3000/api/proizvodi/' + queryParams
    )
    .subscribe(data => {
      this.proizvodi = data.proizvodi;
      this.proizvodiUpdated.next({
        proizvodi: [...this.proizvodi],
        brojProizvoda: data.ukupnoProizvoda
      });
      console.log('proizvod.service: getProizvodi(): gotovo');
    });
  }

  // getProizvodi(kriterijum: string, pojam: string, proizvodiPoStrani: number, trenutnaStrana: number) {
  // const queryParams = `?kriterijum=${kriterijum}&pojam=${pojam}&proizvodiPoStrani=${proizvodiPoStrani}&trenutnaStrana=${trenutnaStrana}`;

  //   // let queryParams = `?id=${id}`;
  //   // queryParams += `&obradjenost=${obradjenost}`;
  //   // queryParams += `&porudzbinaPoStrani=${porudzbinaPoStrani}`;
  //   // queryParams += `&trenutnaStrana=${trenutnaStrana}`;

  //   this.http.get<{ proizvodi: Proizvod[], ukupnoProizvoda: number }>(
  //     'http://localhost:3000/api/proizvodi/' + queryParams
  //   )
  //   .subscribe(data => {
  //     this.proizvodi = data.proizvodi;
  //     this.proizvodiUpdated.next({
  //       proizvodi: [...this.proizvodi],
  //       brojProizvoda: data.ukupnoProizvoda
  //     });
  //     console.log('proizvod.service: getProizvodiPretraga(' + kriterijum + ', ' + pojam + '): ' + data.ukupnoProizvoda);
  //   });
  // }

  // getSviProizvodi() {
  //   console.log('proizvod.service: getSviProizvodi()...');
  //   this.http
  //     .get<{ proizvodi: any }>(
  //       'http://localhost:3000/api/proizvodi-svi'
  //     )
  //     .subscribe(data => {
  //       this.proizvodi = data.proizvodi;
  //       this.proizvodiUpdatedZaSveProizvode.next([...this.proizvodi]);
  //       console.log('proizvod.service: getSviProizvodi() gotovo');
  //     });
  // }

  // STRANICA SA JEDNIM PROIZVODOM
  getProizvod(id: string) {
    console.log('prozvod.service: getProizvod(id: string) za indeks: ' + id);
    return this.http.get<Proizvod>('http://localhost:3000/api/proizvodi/' + id);
  }

  getProizvodUpdateListener() {
    return this.proizvodiUpdated.asObservable();
  }

  updateProizvod(
    idParam: string, nazivParam: string, slikaParam: File | string, sazetOpisParam: string, detaljanOpisParam: string, cenaParam: number,
    kolicinaParam: number, prodato: number, kategorijaParam: string, karakteristikeParam: Karakteristika[], komentariParam: Komentar[]) {
    let proizvodData: Proizvod | FormData;
    if (typeof slikaParam === 'object') {
      proizvodData = new FormData();
      proizvodData.append('_id', idParam);
      proizvodData.append('naziv', nazivParam);
      proizvodData.append('sazetOpis', sazetOpisParam);
      proizvodData.append('detaljanOpis', detaljanOpisParam);
      proizvodData.append('cena', cenaParam.toString());
      proizvodData.append('kolicina', kolicinaParam.toString());
      proizvodData.append('prodato', prodato.toString());
      proizvodData.append('kategorija', nazivParam);
      proizvodData.append('slika', slikaParam, nazivParam);
      proizvodData.append('karakteristike', JSON.stringify(karakteristikeParam));
      proizvodData.append('komentari', JSON.stringify(komentariParam));
    } else {
      proizvodData = {
        _id: idParam,
        naziv: nazivParam,
        sazetOpis: sazetOpisParam,
        detaljanOpis: detaljanOpisParam,
        cena: cenaParam,
        kolicina: kolicinaParam,
        prodato,
        kategorija: kategorijaParam,
        slika: slikaParam,
        karakteristike: karakteristikeParam,
        komentari: komentariParam
      };
    }
    console.log('proizvod.service: updateProizvod(): ID: ' + idParam);
    console.log('proizvod.service: updateProizvod(): azuriranje proizvoda...');
    this.http.put('http://localhost:3000/api/proizvodi/' + idParam, proizvodData)
    .subscribe(response => {
      console.log('proizvod.service: updateProizvod(): successful');
      const updatedProizvodi = [...this.proizvodi];
      const oldProizvodIndex = updatedProizvodi.findIndex(p => p._id === idParam);
      const proizvod: Proizvod = {
        _id: idParam,
        naziv: nazivParam,
        sazetOpis: sazetOpisParam,
        detaljanOpis: detaljanOpisParam,
        cena: cenaParam,
        kolicina: kolicinaParam,
        prodato,
        kategorija: kategorijaParam,
        slika: '',
        karakteristike: karakteristikeParam,
        komentari: komentariParam
      };
      updatedProizvodi[oldProizvodIndex] = proizvod;
      this.proizvodi = updatedProizvodi;
      this.proizvodiUpdated.next({
        proizvodi: [...this.proizvodi],
        brojProizvoda: 15
      });
    });
  }

  // getProizvodiPoKriterijumu(kriterijum: string, odabraniKriterijumPretrage: string) {
  //   console.log('proizvodService: getProizvodiPoKriterijumu( ' + kriterijum + ' )');

  //   if (odabraniKriterijumPretrage === 'ID') {
  //     this.http.get<[]>('http://localhost:3000/api/proizvodi/' + kriterijum)
  //     .subscribe(nadjeniProizvodi => {
  //       console.log('proizvodService: getProizvodiPoKriterijumu() successful ' + JSON.stringify(nadjeniProizvodi));
  //     });
  //   } else if (odabraniKriterijumPretrage === 'Naziv') {

  //   } else if (odabraniKriterijumPretrage === 'Sazet opis') {

  //   } else if (odabraniKriterijumPretrage === '') {
  //     console.log('proizvodService: getProizvodiPoKriterijumu(): Resetovanje pretrage');
  //     this.getSviProizvodi();
  //   }
  // }

  deleteProizvod(id: string) {
    console.log('proizvod.service: deleteProizvod(): ' + id);
    // this.http
    //   .delete('http://localhost:3000/api/proizvodi/' + id)
    //   .subscribe(() => {
    //     const updatedProizvodi = this.proizvodi.filter(proizvod => proizvod._id !== id);
    //     this.proizvodi = updatedProizvodi;
    //     this.proizvodiUpdated.next([...this.proizvodi]);
    // });
    return this.http
      .delete('http://localhost:3000/api/proizvodi/' + id);
  }

  addKomentar(idProizvoda: string, komentar: Komentar) {
    console.log('proizvod.service: addKomentar(): ' + JSON.stringify(komentar) + ', ID: ' + idProizvoda);
    this.http.put('http://localhost:3000/api/komentari/' + idProizvoda, komentar)
      .subscribe(data => {
        console.log(data);
      });
  }

  getNajprodavaniji() {
    // console.log('proizvod.service: addKomentar(): ' + JSON.stringify(komentar) + ', ID: ' + idProizvoda);
    this.http.get('http://localhost:3000/api/najprodavaniji/')
      .subscribe(data => {
        console.log(data);
      });
  }

  // getSviProizvodi(): {proizvodi: Proizvod[]} {
  //   console.log('proizvod.service: getProizvodi()...');
  //   return this.http
  //     .get<{ proizvodi: Proizvod[] }>(
  //       'http://localhost:3000/api/proizvodi/svi'
  //     );
  //     // .subscribe(response => {
  //     //   this.proizvodi = response.proizvodi;
  //     //   console.log('proizvod.service: getProizvodi() gotovo');
  //     //   // return response.proizvodi;
  //     // });
  // }
}
