import { Pipe, PipeTransform } from '@angular/core';
import { Obavestenje } from './obavestenje.model';

@Pipe({
  name: 'obavestenjeNazivPorudzbine'
})
export class ObavestenjeNazivPorudzbine implements PipeTransform {
  transform(obavestenjeNaziv: string, deo: string): string {

    // Lazarevac, Dula Karaklajica 47
    const delovi = obavestenjeNaziv.split(', ');
    if (deo === 'grad') {
      return delovi[0];
    } else {
      return delovi[1];
    }




    // const danas = new Date();
    // const obavestenjeDate = new Date(obavestenjeDateString);
    // let response = '3';
    // console.log('ulazak u pipe sa parametrima: ' + obavestenjeDateString);
    // console.log('danas: ' + danas);
    // console.log('obavestenjeDate: ' + obavestenjeDate);

    // console.log('obavestenjeDate.getDate(): ' + obavestenjeDate.getDate());
    // console.log('danas.getDate(): ' + danas.getDate());


    // if (danas.getDate() === obavestenjeDate.getDate() &&
    // danas.getMonth() === obavestenjeDate.getMonth() &&
    // danas.getFullYear() === obavestenjeDate.getFullYear()) {
    //   response = '5';
    // }
    // // if (danas.getFullYear().toString() === obavestenjeDate.getFullYear().toString()) {
    // //   response = '6';
    // // }
    // // // obavestenje.datumVreme.getDate() === danas.getDate() &&
    // // // obavestenje.datumVreme.getMonth() === danas.getMonth() &&
    // // // obavestenje.datumVreme.getFullYear() === danas.getFullYear();

    // const jesteDanas = obavestenjeDate.getDate() === danas.getDate() &&
    // obavestenjeDate.getMonth() === danas.getMonth() &&
    // obavestenjeDate.getFullYear() === danas.getFullYear();

    // const meseci = [
    //   'januar',
    //   'februar',
    //   'mart',
    //   'april',
    //   'maj',
    //   'jun',
    //   'jul',
    //   'avgust',
    //   'septembar',
    //   'oktobar',
    //   'novembar',
    //   'decembar'
    // ];
    // const daniUNedelji = [
    //   'Nedelja',
    //   'Ponedeljak',
    //   'Utorak',
    //   'Sreda',
    //   'Četvrtak',
    //   'Petak',
    //   'Subota'
    // ];

    // if (jesteDanas) {
    //   return 'Danas, u ' + obavestenjeDate.getHours() + ':' + obavestenjeDate.getMinutes();
    // }
    // return daniUNedelji[obavestenjeDate.getDay()] + ', ' + obavestenjeDate.getDate() + '. ' + meseci[obavestenjeDate.getMonth()];
  }
}
