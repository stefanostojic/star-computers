export interface Korisnik {
  _id: string;
  email: string;
  ime: string;
  prezime: string;
  telefon: string;
  grad: string;
  ulica: string;
  postanskiBroj: number;
}
