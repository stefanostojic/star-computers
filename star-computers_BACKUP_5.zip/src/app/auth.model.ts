export interface AuthData {
  email: string;
  lozinka: string;
}
