export interface Obavestenje {
  _id: string;
  tip: string;
  naziv: string;
  opis: string;
  datumVreme: Date;
  link: string;
  vidjeno: boolean;
}
