import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NataComponent } from './nata.component';

describe('NataComponent', () => {
  let component: NataComponent;
  let fixture: ComponentFixture<NataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
