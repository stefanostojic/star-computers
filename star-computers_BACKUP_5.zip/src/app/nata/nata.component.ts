import { Component, OnInit, OnDestroy } from '@angular/core';
// import { Product } from '../body-products/product.model';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
// import { ProductService } from '../body-products/product.service';
import { ParamMap, ActivatedRoute } from '@angular/router';
// import { UserService } from '../user-form/user.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-nata',
  templateUrl: './nata.component.html',
  styleUrls: ['./nata.component.css']
})
export class NataComponent implements OnInit, OnDestroy {
  constructor() { }


  enteredName = '';
  enteredAbout = '';
  enteredPrice = '';
  public sizes = [] as {size: number, count: number}[];
  mode = false;
  // product: Product;
  productid;
  brands = [];
  chategories = [];
  form: FormGroup;
  private authStatusSub: Subscription;
  userIsAuthenticated = false;




  ngOnInit() {
    this.form = new FormGroup({
    name: new FormControl(null, {validators: [Validators.required]}),
    about: new FormControl (null, {validators: [Validators.required]}),
    price: new FormControl (null, {validators: [Validators.required]}),
    cathegory: new FormControl (null, {validators: [Validators.required]}),
    brand: new FormControl (null, {validators: [Validators.required]}),
    size: new FormControl (null),
    count: new FormControl (null),
    });

    this.brands.push('Nike');
    this.brands.push('Adidas');
    this.brands.push('Reebok');
    this.chategories.push('Men');
    this.chategories.push('Women');
    this.chategories.push('Kids');

    // this.route.paramMap.subscribe((paramMap: ParamMap) => {
    //     if (paramMap.has('_id')) {
    //       this.mode = true;
    //       console.log('mode je edit');
    //       this.productid = paramMap.get('_id');
    //       console.log(this.productid);
    //       this.productService.getProduct(this.productid).subscribe(productData => {
    //           this.product = {_id: productData._id, name: productData.name,
    //           about: productData.about, brand: productData.brand, sizes: productData.sizes, price: productData.price,
    //           cathegory: productData.cathegory};
    //           this.sizes = productData.sizes;
    //           console.log('proizvod: ' + JSON.stringify(this.product));
    //           this.form.setValue({name: this.product.name, about: this.product.about, price: this.product.price,
    //             cathegory: this.product.cathegory, brand: this.product.brand, size: '', count: ''} );
    //         });

    //       }
    //   });
    // this.authStatusSub = this.userService.getAuthStatusListener()
    //     .subscribe(isAuhtenticated => {
    //     this.userIsAuthenticated = isAuhtenticated;
    //   });
  }

  ngOnDestroy(): void {
    // this.authStatusSub.unsubscribe();
  }

  onAddProduct() {
    if (this.mode) {
      console.log('onAddProductSUBMIT is about to be executed');
      if (this.form.invalid) {
      console.log('form is invalid');
      return;
    } else {
      console.log('product is being made');
      // const product: Product = {_id: null,
      //   name: this.form.value.name,
      //   about: this.form.value.about,
      //   price: this.form.value.price,
      //   cathegory: this.form.value.cathegory,
      //   sizes: this.sizes,
      //   brand: this.form.value.brand
      //  };

// console.log('product is made: ' + product.about + product.about + product.price + product.cathegory + product.sizes + product.brand );
      // this.productService.addProduct(product.name, product.about, product.price, product.cathegory, product.sizes, product.brand);
      this.form.reset();
    }
    }

  }

  onAddSizes() {
    console.log('this.sizes: ', this.sizes);
    const sizeFromInput = this.form.value.size;
    const countFromInput = this.form.value.count;

    console.log('sizeFromInput: ', sizeFromInput);
    console.log('countFromInput: ', countFromInput);

    if (sizeFromInput === null) {
      console.log('ne moze da se unese prazna vrednost');
      return;
    }

    const index = this.sizes.findIndex(s => s.size === sizeFromInput);
    if (index === -1) {
      console.log('element nije u nizu, znaci da se dodaje');
      this.sizes.push({size: sizeFromInput, count: countFromInput});
    } else {
      console.log('element je vec u nizu, samo ga treba azurirati');
      this.sizes[index] = {size: sizeFromInput, count: countFromInput};
    }

    // console.log('size from input is:' + sizeFromInput);
    // console.log(this.sizes);
    // this.sizes = this.sizes.filter(s => s.size !== sizeFromInput);
    // console.log('array before pushing');
    // console.log(this.sizes);
    // this.sizes.push({size: sizeFromInput, count: countFromInput});
  }

  onDelete(size: number) {
    console.log('velicina za brisanje: ', size);

    this.sizes = this.sizes.filter(s => s.size !== size);

    // const count = 2;

    // // const count = form.value.countOfsizes;
    // // const size = form.value.sizeOfsizes;
    // console.log(sizeGet.toString());
    // console.log('evo sta je povukao' + sizeGet);
    // this.sizes = this.sizes.filter(notSizeget);

    // function notSizeget(element, index, array) {
    //   return (element.size !== sizeGet);
    // }
}
}
