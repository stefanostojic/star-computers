import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { KorisniciService } from 'src/app/korisnici.service';
import { AuthService } from 'src/app/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.css']
})
export class ProfilComponent implements OnInit {
  profilForm: FormGroup;
  korisnikSub: Subscription;
  greskakSub: Subscription;
  cuvanjeUToku = false;
  prikazUspesnogAzuriranja = false;
  prikazGreske = false;

  constructor(
    private korisnikService: KorisniciService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.profilForm = new FormGroup({
      email: new FormControl(null, { validators: [Validators.required, Validators.email] }),
      ime: new FormControl(null, { validators: [Validators.required] }),
      prezime: new FormControl(null, { validators: [Validators.required] }),
      telefon: new FormControl(null, { validators: [Validators.required] }),
      grad: new FormControl(null, { validators: [Validators.required] }),
      ulica: new FormControl(null, { validators: [Validators.required] }),
      postanskiBroj: new FormControl(null, { validators: [Validators.required, Validators.max(100000), Validators.max(0)] })
    });
    this.profilForm.reset();

    this.korisnikService.getKorisnik(this.authService.getUserId());
    this.korisnikSub = this.korisnikService
      .getKorisnikUpdateListener()
      .subscribe(korisnik => {
        this.profilForm.setValue({
          email: korisnik.email,
          ime: korisnik.ime,
          prezime: korisnik.prezime,
          telefon: korisnik.telefon,
          grad: korisnik.grad,
          ulica: korisnik.ulica,
          postanskiBroj: korisnik.postanskiBroj
        });
        if (this.cuvanjeUToku) {
          this.prikazUspesnogAzuriranja = true;
        }
        this.cuvanjeUToku = false;
      });
    this.greskakSub = this.korisnikService
      .getGreskaStatusUpdateListener()
      .subscribe(greska => {
        this.prikazGreske = greska.status;
      });
  }

  sacuvaj() {
    this.korisnikService.updateKorisnik(
      this.authService.getUserId(),
      this.profilForm.get('email').value,
      this.profilForm.get('ime').value,
      this.profilForm.get('prezime').value,
      this.profilForm.get('telefon').value,
      this.profilForm.get('grad').value,
      this.profilForm.get('ulica').value,
      this.profilForm.get('postanskiBroj').value
    );
    this.cuvanjeUToku = true;
  }
}
