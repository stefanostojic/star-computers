import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treci-red',
  templateUrl: './treci-red.component.html'
})
export class TreciRedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
