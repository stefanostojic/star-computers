import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treci-red-lokacija',
  templateUrl: './treci-red-lokacija.component.html'
})
export class TreciRedLokacijaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
